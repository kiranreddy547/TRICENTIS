package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Demo.DemoLog;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Reports  {
	public static ExtentHtmlReporter obj1=new ExtentHtmlReporter("./reports/extentreport1.html");
	public static ExtentHtmlReporter duplicateobj1=new ExtentHtmlReporter("./reports/extentreport2.html");
	public static ExtentReports obj2=new ExtentReports();
	public static WebDriver driver;
	
	@BeforeClass
	public static void setDriver()
	{
	//	DemoLog.log(1);
		obj2.attachReporter(obj1);
		ExtentTest obj3=obj2.createTest("Opening the Test");
		obj3.log(Status.INFO,"Opening the browser");
		try
		{
	//		DemoLog.log(2);
		WebDriverManager.chromedriver().setup();
	      driver = new ChromeDriver();
	      obj3.log(Status.PASS,"The browser open");
		}
		catch(Exception e)
		{
	//		DemoLog.log(3);
			System.out.println("Before Report block");
			obj3.log(Status.FAIL,"The browser does not opened");
		}
		obj2.flush();
	}
	@Test 
	public static void Registration() throws InterruptedException
	{
//		DemoLog.log(2);
		obj2.attachReporter(duplicateobj1);
		ExtentTest obj4=obj2.createTest("Opening the Application and Searching data");
		obj4.log(Status.INFO,"Opening the Google site");
		try
		{
	//		DemoLog.log(1);
		 driver.get("http://demowebshop.tricentis.com/");
		 obj4.log(Status.PASS,"The application opened in the browser");
	//	 WebElement search=driver.findElement(By.name("q"));
		// search.sendKeys("java");
		 //search.click();
		 ScreenShots.screenShot(1);
		 Thread.sleep(3000);
		 obj4.log(Status.PASS,"The application navigated to the next page");
		 String filepath=System.getProperty("user.dir")+"//ScreenShots//Screenshot1.png";
		 obj4.addScreenCaptureFromPath(filepath);
		}
		catch(Exception e)
		{
	//		DemoLog.log(3);
			System.out.println("Reports");
			obj4.log(Status.FAIL,"The applcation failed");
		}
		
		
		try {
			
			//DemoLog.log(1);
			WebElement mouseMove = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
			obj4.log(Status.PASS,"The applcation failed");
			

			Actions act=new Actions(driver);
			act.moveToElement(mouseMove).build().perform();
			Thread.sleep(2000);
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();

				}
				catch (Exception e){
					System.out.println("Path Not Found");
				}

		try {
			//DemoLog.log(2);
			driver.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
			obj4.log(Status.PASS,"The applcation failed");
				}
				catch (Exception e) {
					System.out.println("Radio");
					//DemoLog.log(1);
				}
			Thread.sleep(2000);
		
		
		try {
			//DemoLog.log(2);
			driver.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Kiran");
			obj4.log(Status.PASS,"The applcation failed");
			Thread.sleep(2000);
		    
		}catch(Exception e){
			System.out.println("Fname");
			//DemoLog.log(3);
		}
		
		try {
			//DemoLog.log(3);
			driver.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("Reddy");
			obj4.log(Status.PASS,"The applcation failed");
			Thread.sleep(2000);
		} catch(Exception e) {
			System.out.println("Lname");
			//DemoLog.log(4);
			
		}
		
		try {
			//DemoLog.log(4);
			driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("kiranreddy1@gmail.com");
			obj4.log(Status.PASS,"The applcation failed");
	
			Thread.sleep(2000);

		}catch(Exception e) {
			System.out.println("Email");
			//DemoLog.log(5);
		}
		
		
		try {
			//DemoLog.log(5);
			driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("kkkk12");
			obj4.log(Status.PASS,"The applcation failed");
			Thread.sleep(2000);

		}catch(Exception e) {
			System.out.println("pswd");
			//DemoLog.log(4);
		}
		
		try {
			//DemoLog.log(3);
			driver.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("kkkk12");
			obj4.log(Status.PASS,"The applcation failed");

			Thread.sleep(2000);
		    
		}catch(Exception e) {
			System.out.println("Cpswd");
			//DemoLog.log(4);
		}
		try {
			//DemoLog.log(3);
			driver.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
			obj4.log(Status.PASS,"The applcation failed");
			Thread.sleep(2000);
			driver.quit();

		}catch(Exception e) {
			System.out.println("Registration ");
			//DemoLog.log(4);
		}
		
		obj2.flush();
		 
		
		
		
		
	}
	@AfterClass
	public static void closeWindow()
	{
		obj2.attachReporter(obj1);
		ExtentTest obj5=obj2.createTest("Closing the browser");
		obj5.log(Status.INFO,"Closing the Application");
		try
		{
	//		DemoLog.log(1);
		driver.close();
		obj5.log(Status.PASS,"The application closed");
		}
		catch(Exception e)
		{
	//		DemoLog.log(2);
			System.out.println("After Reports block");
			obj5.log(Status.FAIL,"The applcation doesn't closed ");
		}
		obj2.flush();
	}
	

}
