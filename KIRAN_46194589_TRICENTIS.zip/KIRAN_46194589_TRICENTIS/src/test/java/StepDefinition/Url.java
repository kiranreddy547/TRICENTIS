package StepDefinition;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;



import Browser.browser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;



public class Url extends browser{



@Given("open the browser")
public void open_the_browser() {
Browser.browser.setDriver();



}



@When("enter the {string}")
public void enter_the(String string) {
browser.getURL(string);

}



@Then("Page is displayed")
public void page_is_displayed() {
try
{
Assert.assertEquals(browser.getTitle(),"Demo Web Shop");
}
catch(Exception e)
{
System.out.println("Title not found");
}
//browser.closeBrowser();

}



	}
