package StepDefinition;



import java.util.List;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import Browser.browser;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Registerurl extends browser {

@Given("open the browser {string}")
public void open_the_browser(String string) {
	
browser.setDriver();
browser.getURL(string);
}


@When("clicks on Register link")
public void clicks_on_Register_link() throws InterruptedException{
	try {
WebElement mouseMove = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
	

Actions act=new Actions(driver);
act.moveToElement(mouseMove).build().perform();
Thread.sleep(2000);
driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();

	}
	catch (Exception e){
		System.out.println("Path Not Found");
	}
}



@When("User clicks Gender")
public void user_clicks_Gender() throws InterruptedException {
	try {
driver.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
	}
	catch (Exception e) {
		System.out.println("Radio");
	}
Thread.sleep(2000);

}



@When("user Enters {string} as First name")
public void user_Enters_as_First_name(String string) throws InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(string);
	Thread.sleep(2000);
    
}

@When("user Enters {string} as Last name")
public void user_Enters_as_Last_name(String string) throws InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(string);
	Thread.sleep(2000);
    
}

@When("user Enters {string} has to be entered as Email")
public void user_Enters_has_to_be_entered_as_Email(String string) throws InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(string);
	Thread.sleep(2000);
}

@When("{string} has to be entered as Password")
public void has_to_be_entered_as_Password(String string) throws InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(string);
	Thread.sleep(2000);
    
}

@When("{string} has to be entered")
public void has_to_be_entered(String string) throws InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(string);
	Thread.sleep(2000);
    
}
@Then("registration must be successful")
public void registration_must_be_successful() throws InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
	Thread.sleep(2000);
	driver.quit();
}



}





