package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Browser.browser;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class InvalidReg extends browser {
	
	
	
	
	
	
	
	@Given("Opens {string}")
	public void opens(String string) {
		browser.setDriver();
		browser.getURL(string);

	}

	@Given("User click Register link")
	public void user_click_Register_link() throws InterruptedException {
		WebElement mouseMove = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
		Actions act=new Actions(driver);
		act.moveToElement(mouseMove).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();

	}

	@Given("user click Gender")
	public void user_click_Gender() {
		driver.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
	}

	@Given("user Enter {string} as Firstname")
	public void user_Enter_as_Firstname(String string) {
		driver.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Kiran");
	}

	@Given("user Enter {string} as Lastname")
	public void user_Enter_as_Lastname(String string) {
		driver.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("Reddy");
	}

	@Given("user Enter {string} has to be enter Emailid")
	public void user_Enter_has_to_be_enter_Emailid(String string) throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("Kirankumarreddy8142gmail.com");
		Thread.sleep(2000);
	}

	@Given("{string}           Password")
	public void password(String string) {
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("Kiran@547");
	}

	@Given("{string} Confirm")
	public void confirm(String string) {
		driver.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("Kiran@547");
	    
	}

	@Then("registration not successfull")
	public void registration_not_successfull() {
		driver.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		driver.quit();
	}


}
