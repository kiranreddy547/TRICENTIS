package StepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;import Browser.browser;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Login extends browser {
@Given("User navigates to the website {string}")
public void user_navigates_to_the_website(String string) {
browser.setDriver();
browser.getURL(string);
}

@When("user clicks on login button")
public void user_clicks_on_login_button() throws InterruptedException {
WebElement mouseMove = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a"));
Actions act=new Actions(driver);
act.moveToElement(mouseMove).build().perform();
Thread.sleep(2000);
driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
}
@When("User logs in through login button by using {string} as {string}")
public void user_logs_in_through_login_button_by_using_as(String string, String string2) throws InterruptedException {
driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("KIRANKUMARREDDY.BUSIREDDY@CAPGEMINI.COM");
Thread.sleep(2000);
}
@When("{string} has to be entered as {string}")
public void has_to_be_entered_as(String string, String string2) throws InterruptedException {
driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("Tricentis");
Thread.sleep(2000);
}
@Then("login must be successful")
public void logiun_must_be_successful() {
driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
}
}